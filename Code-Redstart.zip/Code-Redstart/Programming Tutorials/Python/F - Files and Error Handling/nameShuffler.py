import random
def shufArr(a):
	out = []
	while(len(a) > 0):
		r = random.randint(1, len(a)) -1
		out.append(a[r])
		a.remove(a[r])
	return out

def readNames(s):
	try:
		file = open(s, "r")
		content = file.read()
		file.close()
		return content.split()
	except FileNotFoundError:
		print("File","\"" + s + "\"", "not found.")
		return 

def writeNames(arr):
	with open("names.txt", "w") as f:
		for i in arr:
				f.write(str(i) + "\n")

def sortFile(s):
	print("Shuffling on \"" + s + "\"")
	arr = readNames(s)
	if not arr == None: 
		writeNames(shufArr(arr))
	print("Done.")
	return
	
def main():
	sortFile("notAFile.txt")
	sortFile("names.txt")
main()
