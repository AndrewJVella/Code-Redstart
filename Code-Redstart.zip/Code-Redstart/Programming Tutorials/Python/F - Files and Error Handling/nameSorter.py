def swap(arr, a, b):
	temp = arr[a]
	arr[a] = arr[b]
	arr[b] = temp
	return arr


def partition(arr, low, high):
	pivot = arr[high] #largest index is our partition
	i = low -1
	for j in range(low, high):
		if arr[j] < pivot:
			i += 1
			swap(arr, i, j)
	swap(arr, i + 1, high)
	return i + 1

def quickSort(arr, low = 0, high = -1):
				#whole array by default
	if high == -1:
		high = len(arr) -1

	if (low < high):
		partitionIndex = partition(arr, low, high)
		#recursively sort either side of the partition
		quickSort(arr, low, partitionIndex - 1)
		quickSort(arr, partitionIndex + 1, high)
	return arr

def readNames(s):
	try:
		file = open(s, "r")
		content = file.read()
		file.close()
		return content.split()
	except FileNotFoundError:
		print("File","\"" + s + "\"", "not found.")
		return 

def writeNames(arr):
	with open("names.txt", "w") as f:
		for i in arr:
			f.write(str(i) + "\n")

def sortFile(s):
	print("Sorting on \"" + s + "\"")
	arr = readNames(s)
	if not arr == None: 
		writeNames(quickSort(arr))
	print("Done.")
	return
	
def main():
	sortFile("notAFile.txt")
	sortFile("names.txt")
main()
