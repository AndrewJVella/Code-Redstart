import subprocess
import os


def getFiles(extension = ".py", inDir = ""):
  
   if not inDir == "":
      if not inDir[0] == "/":
         inDir = "/" + inDir

   if not extension == "":
      if not extension[0] == ".":
         extension = "." + extension

   dirs = os.listdir(os.getcwd() + inDir)
   dirs.remove("test.py")
   fileSet = []

   for directory in dirs:
      dirfiles =  os.listdir(directory)
      for file in dirfiles:
         if file.endswith(extension):
            fileSet.append(directory +"/"+file)
   return fileSet


def runTests(command, fileSet, pause = True):
   fails = []

   for file in fileSet:
      print("\nRunning: \"" + file + "\"\n")

      #I have to do this to prevent fnf errors in subprocesses. I know...
      dirr = file.split("/")[0]
      filey = file.split("/")[1]

      os.chdir(dirr) #go to directory of tested program 
      test = subprocess.run(["python", str(filey)], check=False) # check=False means continue after an error
      os.chdir('..') #go to parent dir
   
      if test.returncode > 0: #if there is an error
         fails.append((file, test.returncode, test.stderr))
      
      if pause:
         input("Exit code: " + str(test.returncode) + "\nPress enter to continue to the next test.\n> ")


   print("Fails on", len(fails), "tests")
   for fail in fails:
      print(fail[0], fail[1])
   exit() #lol it started running the whole thing again, so quit


def main(command, extension, inDir = "", pause = True):
   #inDir specifier, is so this module can be run from any parent directory 
   #The pause toggle is turned off when main is being run more than once.
   #I may, in the future, want to offer this course in more languages, that require an initial test for compilation.
   #In such an event, I would want to run a compilation test on all source files without stopping 
   #and then run tests on the resulting byte code, with pauses, so I can read the output of each execution while testing
   fileSet = getFiles()
   print("Running on", len(fileSet), "files")
   for file in fileSet:
      print(file)

   for file in fileSet:
      runTests(command, fileSet, pause)



main("python", ".py")
# Known issue, programs that access text files will always fail. 
# I think that, because the program is called from a subprocess, the current working directory is not updated for file access.
# The programs work fine when run independently

# turtle.Terminator also reterns exit status 1. It might be nice just to handle that error in every turtle program.
# So my nice visuals do not end with a bunch of red text in a stack trace.
# Ok, I did that


