import random

#This file features two variations of quickSort, the original (Hoare's sort) and Lamuto's version.

#https://www.geeksforgeeks.org/dsa/quick-sort-algorithm/
#https://www.geeksforgeeks.org/dsa/hoares-vs-lomuto-partition-scheme-quicksort/

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out

def swap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        return arr

def partition(arr, low, high):

    pivot = arr[low]
    i = low - 1
    j = high + 1

    while (True):

        # Find leftmost item greater than
        # or equal to pivot
        i += 1
        while (arr[i] < pivot):
            i += 1

        # Find rightmost item smaller than
        # or equal to pivot
        j -= 1
        while (arr[j] > pivot):
            j -= 1

        # If two pointers met.
        if (i >= j):
            return j

        temp = arr[i]
        arr[i] = arr[j]
        arr[j] = temp


def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        print("LH:", low, high, arr)

        if (low < high):
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex)
                quickSort(arr, partitionIndex + 1, high)
        return arr

def partitionLamuto(arr, low, high):
        pivot = arr[high] #largest index is our partition
        i = low -1
        for j in range(low, high):
                if arr[j] < pivot:
                        i += 1
                        swap(arr, i, j)
                        #print(arr, "pivot:", pivot)
        swap(arr, i + 1, high)
        #print(arr, "pivot:", pivot)
        return i + 1




def quickSortLamuto(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        print("LH:", low, high, arr)

        if (low < high):
                partitionIndex = partitionLamuto(arr, low, high)
                #recursively sort either side of the partition
                quickSortLamuto(arr, low, partitionIndex - 1)
                quickSortLamuto(arr, partitionIndex + 1, high)
        return arr

def main(n):
    print("Quick Sort (Original):\n")
    arr = ordArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

    arr = revArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

    print("Quick Sort (Lamuto):\n")
    arr = ordArr(n)
    print(arr)
    print(quickSortLamuto(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(quickSortLamuto(arr))
    print("--")

    arr = revArr(n)
    print(arr)
    print(quickSortLamuto(arr))
    print("--")






if __name__ == '__main__':
        main(10)
