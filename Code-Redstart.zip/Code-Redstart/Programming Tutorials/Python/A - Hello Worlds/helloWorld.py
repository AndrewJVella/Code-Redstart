print("Hello World!")
