from turtle import *

import time
import math
import random


CAPTION = ""
RENDERS = 0
DELAY = 0
#https://cs111.wellesley.edu/reference/colors
COLORS = ["black", "linen", "MediumOrchid",  "green3", "brown2"] #background color, array color, reading color, verifing color, disqualifying color

def maxScreen(): #https://stackoverflow.com/questions/34687998/turtle-screen-fullscreen-on-program-startup/60138928#60138928
    screen = Screen()
    screen.setup(width = 1.0, height = 1.0)
    canvas = screen.getcanvas()
    root = canvas.winfo_toplevel()
    #root.overrideredirect(1) #comment this out so for the window buttons

def setCaption(s):
    global CAPTION
    CAPTION = s

def texter(text, size = 16):
    size = int(size)
    down()
    write(text, align="center", font=("Helvetica", size, "bold"))
    up()


#RENDERING
def init(x = 600, y = 450):
    global COLORS

    #screen
    screensize(x,y)
    bgcolor(COLORS[0])
    ht()
    tracer(False)
    setundobuffer(None)
    maxScreen()

def render(arr, readIndicies = [], cSpec = 2, x = 600, y = 450, buffer = 1, bezel = .1, drawbounds = False): #this is a one dimensional array of ints
        global DELAY
        global COLORS
        #do not render
        if len(arr) == 0:
            return

        #init for render
        floor = int(-(y / 2) * (1 - bezel))
        roof = int((y / 2) * (1 - bezel))
        lwall = int(-(x) * (1 - bezel))
        rwall = int((x) * (1 - bezel))

        width = (rwall - lwall)
        height = (roof - floor)
        barWidth = width // len(arr)

        if barWidth == 0:
            barWidth == 1
            buffer = 0

        #adjusting walls to center the render
        actWidth = barWidth * len(arr)
        barWidth = int(barWidth * (width / actWidth))
        actWidth = barWidth * len(arr)

        adjust = (actWidth - width) // 2
        rwall = rwall + adjust
        lwall = lwall - adjust

        pensize(barWidth - buffer)

        color(COLORS[1])
        maxValue = getMaxValue(arr)
        i = 0
        clear()
        up()
        #print caption
        global CAPTION
        global RENDERS

        text = CAPTION
        if RENDERS > -1:
            text += " (" + str(RENDERS + 1) + ")"
            RENDERS += 1
        size = 16
        goto(0, floor - (size * 2) -  (barWidth))
        texter(text, size)

        #draw array as bargraph
        while i < len(arr):
            color(COLORS[1])

            if i in readIndicies:
                color(COLORS[cSpec])

            #draw a bar proportional to array value, at a location mapped to array index
            goto(lwall + (barWidth * (i+1)), int(floor + (height * (arr[i] / maxValue)) + (barWidth)))
            down()
            goto(xcor(), floor) #to the floor
            up()
            i = i + 1
        if drawbounds:
            up()
            pensize(1)
            goto(lwall, roof)
            down()
            color(COLORS[2])
            goto(rwall, roof)
            goto(rwall, floor)
            goto(lwall, floor)
            goto(lwall, roof)

        vals = []
        x = (100 / len(arr)) * 10
        for i in readIndicies:
            vals.append(220 + (i * x))

        update()
        #synthia.load_sound(vals)
        #synthia.play_sound()
        
        if DELAY > 0:
            time.sleep(DELAY / 1000) #delay in millis

#this is an inplace shuffle
def shuffle(arr):
    n = len(arr) * 2
    i = 0
    while i < n:
        #print(arr)
        a = random.randint(0, len(arr) -1)
        b = a
        #ensure that b is not a
        while (a == b):
            b = random.randint(0, len(arr) -1)
            arr = doSwap(arr, a, b)
            i = i + 1
    return arr


def swapCheck(arr, a, b):
        if (arr[a] > arr[b]):
                arr = doSwap(arr, a, b)
        return arr

def doSwap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        render(arr, [a, b])
        return arr

#ARRAY GENERATOR FUNCTIONS

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out

#AUXILARIES
def verify(arr, rendering = True):
        for i in range(1, len(arr)):
            if (arr[i] < arr[i-1]):
                render(arr, [i-1, i], 4)
                return False
            if rendering:
                render(arr, [i-1, i], 3)

        if rendering:
            render(arr)
        return True

def getMaxValue(arr):
    maxValue = arr[0]
    for i in arr:
        if maxValue < i:
            maxValue = i
    #print(arr)
    #print("MAX VALUE:", maxValue)
    return maxValue

def partition(arr, low, high):

    pivot = arr[low]
    i = low - 1
    j = high + 1

    while (True):

        # Find leftmost item greater than
        # or equal to pivot
        i += 1
        while (arr[i] < pivot):
            i += 1
            render(arr, [i])

        # Find rightmost item smaller than
        # or equal to pivot
        j -= 1
        while (arr[j] > pivot):
            j -= 1
            render(arr, [j])

        # If two pointers met.
        if (i >= j):
            render(arr, [j])
            return j

        temp = arr[i]
        arr[i] = arr[j]
        arr[j] = temp
        render(arr, [i, j])

def heapify(arr, n, i):

    # Initialize largest as root
    largest = i
    # left child index = 2*i + 1
    left = 2 * i + 1
    # right child index = 2*i + 2
    right = 2 * i + 2

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    # If largest is not root
    if largest != i:

        #swap
        temp = arr[i]
        arr[i] = arr[largest]
        arr[largest] = temp

        # Recursively heapify all subheaps
        heapify(arr, n, largest)
    render(arr, [i])
    return arr



#s, w, and e; pointers to the start, middle, and end indices on an array, to partition the array in place
def merge(arr, s, m, e):
    merge = []
    left = s
    right = m

    #merging
   # print("subarray:", arr)
    #print ("left:", arr[left:m], "right:", arr[right:e])
    while left < m and right < e:
        render(arr, [left, right])
        if arr[left] < arr[right]:
            merge.append(arr[left])
            left = left + 1
            continue
        if arr[right] < arr[left]:
            merge.append(arr[right])
            right = right + 1
            continue
        if arr[left] == arr[right]:
            merge.append(arr[left])
            merge.append(arr[right])
            left = left + 1
            right = right + 1

    #add any leftovers to merge list
    if left == m:
        while right < e:
            merge.append(arr[right])
            right = right + 1
    if right == e:
        while left < m:
            merge.append(arr[left])
            left = left + 1


    #write merge to array
    x = 0
    while (s + x) < e:
        arr[s + x] = merge[x]
        x = x + 1
        render(arr, [s+x])
    return arr #BEHOLD! THE ENTIRE ARRAY WILL BE RETURNED IN FULL!

#SORTS

def mergeSort(arr, s = 0, e = -1):
    if e == -1: #defaults to sorting the entire array
        e = len(arr)

    #base cases
    if e - s < 2: #if array is too small to require any sorting
        return arr
    if e - s == 2 and arr[s] > arr[s + 1]: #if array is of two items, swap as needed
        t = arr[s]
        arr[s] = arr[s+1]
        arr[s+1] = t
        render(arr, [s, s+1])

        return arr

    #get the middle, dividing into left and right
    m = (s + e) // 2

    arr = mergeSort(arr, s, m) #sort left
    arr = mergeSort(arr, m, e) #sort right
    arr = merge(arr, s, m, e) #merges left and right as a sorted array
    #print(arr)
    return arr


def heapSort(arr):

    #The key here is that every unsorted value will eventually be the root (index 0), and then get sorted
    #That is why the max is used. This took me several hours to understand because no tutorial bothers to explain that.
    n = len(arr)

    # Build heap

    halfwayPoint = (n // 2 - 1)
    for i in range(halfwayPoint, -1, -1):
        arr = heapify(arr, n, i)


    for i in range(n - 1, 0, -1):
        # Move current root to end
        temp = arr[0]
        arr[0] = arr[i]
        arr[i] = temp
        render(arr, [i])

        # Call max heapify on the reduced heap
        heapify(arr, i, 0)
    return arr

def bubbleSort(arr):
        if len(arr) < 2: #already sorted case
                return arr

        #given arr is an array
        n = len(arr)
        i = 0
        x = 1

        while(x < (n + 1)):
                while(i < n - x):
                        swapCheck(arr, i, i+1)
                        i = i +1
                i =0
                x = x+1
        return arr

def selectionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        maxIndex = len(arr) - 1
        maxValue = -1

        while(maxIndex > 0):
                i = 0
                indexUnsortedMax = -1
                #get max unsorted value
                while (i <= maxIndex):  #this inequality was diabolical. It took an hour to notice I had written '<', not '<='.
                        if arr[i] > maxValue:
                                maxValue = arr[i]
                                indexUnsortedMax = i
                        render(arr, [i])
                        i = i + 1
                if indexUnsortedMax > - 1:
                        doSwap(arr, maxIndex, indexUnsortedMax)
                        maxValue = -1
                i = 0
                maxIndex = maxIndex - 1
        return arr

def insertionSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        for i in range (0, len(arr) -1):
            j = i + 1
            while j > 0:
                swapCheck(arr, j-1, j)
                j = j - 1
        return arr

def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        #print("LH:", low, high, arr)

        if (low < high):
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex)
                quickSort(arr, partitionIndex + 1, high)
        return arr


def bozoSort(arr):
        while not verify(arr):
               # print(arr)
                a = random.randint(0, len(arr) -1)
                b = a
                #ensure that b is not a
                while (a == b):
                        b = random.randint(0, len(arr) -1)
                arr = doSwap(arr, a, b)
                #adds a delay
        return arr

def bogoSort(arr):
        while not verify(arr):
            shuffle(arr)
        return arr

def shellSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        n = len(arr)
        gap = n // 2
        while gap > 0:
                #insertion sort, on a gap sized to (n - gap)
                for i in range (gap, n):
                        temp = arr[i]
                        j = i

                        while j >= gap and arr[j - gap] > temp:
                                arr[j] = arr[j - gap]
                                j = j - gap
                        arr[j] = temp
                        render(arr, [i, j])
                gap = gap // 2
        return arr


def sortIt(s, arr):
    global RENDERS

    if s == "Bubble":
        setCaption("Bubble Sort")
        arr = bubbleSort(arr)
        return
    if s == "Select":
        setCaption("Selection Sort")
        arr = selectionSort(arr)
        return
    if s == "Insert":
        setCaption("Insertion Sort")
        arr = insertionSort(arr)
        return
    if s == "Shell":
        setCaption("Shell Sort")
        arr = shellSort(arr)
        return
    if s == "Merge":
        setCaption("Merge Sort")
        arr = mergeSort(arr)
        return
    if s == "Heap":
        setCaption("Heap Sort")
        arr = heapSort(arr)
        return
    if s == "Quick":
        setCaption("Quick Sort")
        arr = quickSort(arr)
        return
    if s == "Bozo":
        setCaption("Bozo Sort")
        arr = bozoSort(arr)
        return
    if s == "Bogo":
        setCaption("Bogo Sort")
        arr = bogoSort(arr)
        return
    else:
        if random.randint(1, 10) > 5:
            setCaption("Bozo Sort")
            arr = bozoSort(arr)
            return
        if random.randint(1, 10) < 6:
            setCaption("Bogo Sort")
            arr = bogoSort(arr)
            return

        return

def doSorts(n = 100, delay = 0):
    n = int(n)
    if n < 50:
        n = 50
    if n > 400:
        n = 400
    global RENDERS
    global DELAY
    DELAY = delay
    RENDERS = -1 #stop displaying renders
    SORTS =  ["Quick", "Merge", "Heap", "Shell", "Insert", "Select", "Bubble", "End"]

    dcap = ""
    if DELAY > 0:
        dcap = " with Delay of " + str(delay) + " Milliseconds"
    setCaption("Sorting on " + str(n) + " Items" + dcap)
    arr = ordArr(n)
    #synthia.load_sound()
    render(arr)
    time.sleep(1)
    arr = shuffle(arr)
    render(arr)
    

    for sort in SORTS:
        #synthia.mute()
        time.sleep(1)

        RENDERS = 0 #display renders
        sortIt(sort, arr)
        RENDERS = -1 #stop displaying renders
        setCaption("Checking")
        verify(arr)
        #synthia.mute()
        time.sleep(1)
        setCaption("Shuffle")
        arr = shuffle(arr)
        render(arr)


def main():
    try:
        init()
        doSorts(100, 0)
    except Terminator:
        pass #optional try-except for the stacktrace

if __name__ == '__main__':
    main()
