from turtle import *
import random
import time
import math

global CAPTION
global RENDERS
global DELAY


#FIXME
#Merge function is not linear, and incorrect for demonstration.
#We should merge out of place, rather than inplace, and overwrite subarrays with the merged subarray

#Also, it would be nice to get Timsort working...
#It is literally the default sort for python, but I want a implementation I can demonstrate
#After timsort, we have a sort for each chapter in the course

#Would also be nice to format the screen for sizes other than 100. 
#Stuff gets shoved to the middle of the screen after that



# In place merge sort is contributed by 29AjayKumar 
#(https://www.geeksforgeeks.org/dsa/in-place-merge-sort/)
#That said, the merge is incorrect for the purposes of this assignment
#it behaves like a local insertion sort, rather than a linear time merge
#so I think it is best to merge out of place, and than overwrite the portion of the array that was merged


def merge(arr, start, mid, end):
    start2 = mid + 1

    # If the direct merge is already sorted
    if (arr[mid] <= arr[start2]):
        return

    # Two pointers to maintain start
    # of both arrays to merge
    while (start <= mid and start2 <= end):

        # If element 1 is in right place
        if (arr[start] <= arr[start2]):
            start += 1
        else:
            value = arr[start2]
            index = start2

            # Shift all the elements between element 1
            # element 2, right by 1.
            while (index != start):
                arr[index] = arr[index - 1]
                index -= 1
                render(arr, [index])

            arr[start] = value

            # Update all the pointers
            start += 1
            mid += 1
            start2 += 1


# merge sort makes log n recursive calls
# and each time calls merge()
def mergeSort(arr, s, e):

    if s == e:
        return

    # Calculating mid to slice the
    # array in two halves
    m = (s + e) // 2

    # Recursive calls to sort left
    # and right subarrays
    mergeSort(arr, s, m)
    mergeSort(arr, m + 1, e)
    merge(arr, s, m, e)
# End of contribution by adityapande88 
#(https://www.geeksforgeeks.org/dsa/in-place-merge-sort/)
#Thanks!


def setCaption(s):
	global CAPTION
	CAPTION = s

def texter(text, size = 16):
	size = int(size)
	down()
	write(text, align="center", font=("Helvetica", size, "bold"))
	up()


def swapCheck(arr, a, b):
        if (arr[a] > arr[b]):
                arr = doSwap(arr, a, b)
        return arr

def doSwap(arr, a, b):
		temp = arr[a]
		arr[a] = arr[b]
		arr[b] = temp
		render(arr, [a, b])
		return arr

#ARRAY GENERATOR FUNCTIONS

def natN(n): #checks if n is a natural number
		try:
				n = int(n)
		except ValueError:
				return False
		if (n < 1):
				return False
		return True

def ordArr(n):
		# produces an ordered list of natural numbers from 1
		if not natN(n):
				return [1, 2, 3]
		out = []
		for i in range(n):
				out.append(i + 1)
		return out

#AUXILARIES
def verify(arr, rendering = True):
		for i in range(0, len(arr) -1):
			if (arr[i] > arr[i+1]):
				return False
			if rendering:
				render(arr, [i]) #turn the verfied parts green
		
		if rendering:		
			render(arr, [i + 1]) #turn the verfied parts green
			render(arr) #turn the verfied parts green
		return True

def getMaxValue(arr):
	maxValue = arr[0]
	for i in arr:
		if maxValue < i:
			maxValue = i
	#print(arr)
	#print("MAX VALUE:", maxValue)
	return maxValue

def partition(arr, low, high):
		pivot = arr[high] #largest index is our partition
		i = low -1
		for j in range(low, high):
				if arr[j] < pivot:
						i += 1
						doSwap(arr, i, j)
		doSwap(arr, i + 1, high)
		return i + 1


def heapify(arr, n, i):
	
	# Initialize largest as root
	largest = i
	# left child index = 2*i + 1
	left = 2 * i + 1
	# right child index = 2*i + 2
	right = 2 * i + 2

	if left < n and arr[left] > arr[largest]:
		largest = left

	if right < n and arr[right] > arr[largest]:
		largest = right

	# If largest is not root
	if largest != i:

		#swap
		temp = arr[i] 
		arr[i] = arr[largest]
		arr[largest] = temp

		# Recursively heapify all subheaps
		heapify(arr, n, largest)
	render(arr, [i])
	return arr



#SORTS

def heapSort(arr):

	#The key here is that every unsorted value will eventually be the root (index 0), and then get sorted
	#That is why the max is used. This took me several hours to understand because no tutorial bothers to explain that.
	n = len(arr)

	# Build heap

	halfwayPoint = (n // 2 - 1)
	for i in range(halfwayPoint, -1, -1):
		arr = heapify(arr, n, i)
		

	for i in range(n - 1, 0, -1):
		# Move current root to end
		temp = arr[0]
		arr[0] = arr[i]
		arr[i] = temp
		render(arr, [i])

		# Call max heapify on the reduced heap
		heapify(arr, i, 0)
	return arr

def bubbleSort(arr):
		if len(arr) < 2: #already sorted case
				return arr
		
		#given arr is an array
		n = len(arr)
		i = 0
		x = 1

		while(x < (n + 1)):
				while(i < n - x):
						swapCheck(arr, i, i+1)
						i = i +1
				i =0
				x = x+1
		return arr

def selectionSort(arr):
		if len(arr) < 2: #already sorted case
				return arr
		maxIndex = len(arr) - 1
		maxValue = -1

		while(maxIndex > 0):
				i = 0
				indexUnsortedMax = -1
				#get max unsorted value
				while (i <= maxIndex):  #this inequality was diabolical. It took an hour to notice I had written '<', not '<='. 
						if arr[i] > maxValue:
								maxValue = arr[i]
								indexUnsortedMax = i
						render(arr, [i])
						i = i + 1
				if indexUnsortedMax > - 1:
						doSwap(arr, maxIndex, indexUnsortedMax)
						maxValue = -1
				i = 0
				maxIndex = maxIndex - 1
		return arr
				
def insertionSort(arr): 
		if len(arr) < 2: #already sorted case
				return arr
		for i in range (0, len(arr) -1):
			j = i + 1
			while j > 0:
				swapCheck(arr, j-1, j)
				j = j - 1
		return arr

def quickSort(arr, low = 0, high = -1):
		if verify(arr, False):
			return arr #this prevents wierd stalls at the ends of the sort
		#whole array by default
		if high == -1:
			high = len(arr) -1

		if (low < high):
			partitionIndex = partition(arr, low, high)
			#recursively sort either side of the partition
			quickSort(arr, low, partitionIndex - 1)
			quickSort(arr, partitionIndex + 1, high)
		return arr

def bozoSort(arr):
        while not verify(arr):
               # print(arr)
                a = random.randint(0, len(arr) -1)
                b = a
                #ensure that b is not a
                while (a == b):
                        b = random.randint(0, len(arr) -1)
                arr = doSwap(arr, a, b)
                #adds a delay
        return arr

def shellSort(arr):
        if len(arr) < 2: #already sorted case
                return arr
        n = len(arr)
        gap = n // 2
        while gap > 0:
                #insertion sort, on a gap sized to (n - gap)
                for i in range (gap, n):
                        temp = arr[i]
                        j = i

                        while j >= gap and arr[j - gap] > temp:
                                arr[j] = arr[j - gap]
                                j = j - gap          
                        arr[j] = temp
                        render(arr, [i, j])
                gap = gap // 2
        return arr


#RENDERING

def init(x = 600, y = 450):
	#just some init
	screensize(x,y)
	bgcolor("black")
	#shape("turtle")
	ht()
	tracer(False)
	setundobuffer(None)



def render(arr, readIndicies = [], x = 600, y = 450, buffer = 1, bezel = .1): #this is a one dimensional array of ints
		global DELAY
		#do not render
		if len(arr) == 0:
			return
		if DELAY > 0:
			time.sleep(DELAY / 1000) #delay in millis

		#init for render
		floor = int(-(y / 2) * (1 - bezel))
		roof = int((y / 2) * (1 - bezel))
		lwall = int(-(x /2) * (1 - bezel))
		rwall = int((x / 2) * (1 - bezel))

		width = (rwall - lwall)
		height = (roof - floor)
		barWidth = width // len(arr) 
		pensize(barWidth - buffer)
		

	#https://cs111.wellesley.edu/reference/colors
		COLORS = ["Seashell2", "green3"]

		color(COLORS[0])
		maxValue = getMaxValue(arr)
		i = 0
		clear()
		up()
		#print caption
		global CAPTION
		global RENDERS

		text = CAPTION
		if RENDERS > -1:
			text += " (" + str(RENDERS + 1) + ")"
			RENDERS += 1
		size = 16
		goto(0, floor - (size * 2) -  (barWidth))
		texter(text, size)


		#draw array as bargraph
		while i < len(arr):
			color(COLORS[0])

			if i in readIndicies: #green meaans this item is being read
				color(COLORS[1])

			#draw a bar proportional to array value, at a location mapped to array index
			goto(lwall + (barWidth * (i+1)) - (barWidth // 2), int(floor + (height * (arr[i] / maxValue)) + (barWidth))) 			
			down()
			goto(xcor(), floor) #to the floor
			up()
			i = i + 1
		update()
#this is an inplace shuffle
def shuffle(arr):
	n = len(arr) * 2
	i = 0
	while i < n:
		#print(arr)
		a = random.randint(0, len(arr) -1)
		b = a
		#ensure that b is not a
		while (a == b):
			b = random.randint(0, len(arr) -1)
			arr = doSwap(arr, a, b)
			i = i + 1
	return arr


def sortIt(s, arr):
	global RENDERS
	
	if s == "Bubble":
		setCaption("Bubble Sort")
		arr = bubbleSort(arr)
		return
	if s == "Select":
		setCaption("Selection Sort")
		arr = selectionSort(arr)
		return
	if s == "Insert":
		setCaption("Insertion Sort")
		arr = insertionSort(arr)
		return
	if s == "Shell":
		setCaption("Shell Sort")
		arr = shellSort(arr)
		return
	if s == "Merge":
		setCaption("Merge Sort")
		arr = mergeSort(arr, 0, len(arr) - 1) 
		return
	if s == "Heap":
		setCaption("Heap Sort")
		arr = heapSort(arr)
		return
	if s == "Quick":
		setCaption("Quick Sort")
		arr = quickSort(arr)
		return
	if s == "Bozo":
		setCaption("Bozo Sort")
		arr = bozoSort(arr)
		return
	else:
		return

def sorts(n = 100, delay = 0):
	n = int(n)
	if n < 10:
		n = 10
	global RENDERS
	global DELAY
	DELAY = delay
	RENDERS = -1 #stop displaying renders
	init()
	SORTS =  ["Bubble", "Insert", "Shell", "Merge", "Heap", "Quick", "Select", "Bozo"]

	dcap = ""
	if DELAY > 0:
		dcap = " with Delay of " + str(delay) + " Milliseconds"
	setCaption("Sorting on " + str(n) + " Items" + dcap)
	arr = ordArr(n)
	render(arr)
	time.sleep(1)
	
	arr = shuffle(arr)
	render(arr)
	for sort in SORTS:
		time.sleep(1)
		RENDERS = 0 #display renders
		sortIt(sort, arr)
		RENDERS = -1 #stop displaying renders
		setCaption("Checking")
		verify(arr)
		time.sleep(1)
		setCaption("Shuffle")
		arr = shuffle(arr)
		render(arr)

		
	
try: 
	sorts()
except Terminator:
	pass #optional try-except for the stacktrace
