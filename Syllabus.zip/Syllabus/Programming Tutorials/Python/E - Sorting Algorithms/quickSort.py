import random

def natN(n): #checks if n is a natural number
        try:
                n = int(n)
        except ValueError:
                return False
        if (n < 1):
                return False
        return True

def ordArr(n):
        # produces an ordered list of natural numbers from 1
        if not natN(n):
                return [1, 2, 3]
        out = []
        for i in range(n):
                out.append(i + 1)
        return out
def revArr(n):
        #produces reversed list
        #can also use: return ordArr(n).reverse()
        a = ordArr(n)
        out = []
        i = len(a) - 1
        while (i > -1):
                out.append(a[i])
                i = i -1

        return out

def shufArr(n):
        #produces shuffled list
        a = ordArr(n)
        out = []

        while(len(a) > 0):
                r = random.randint(1, len(a)) -1
                #print(r)
                out.append(a[r])
                a.remove(a[r])
        return out

def swap(arr, a, b):
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp
        return arr


def partition(arr, low, high):
        pivot = arr[high] #largest index is our partition
        i = low -1
        for j in range(low, high):
                if arr[j] < pivot:
                        i += 1
                        swap(arr, i, j)
                        print(arr, "pivot:", pivot)
        swap(arr, i + 1, high)
        print(arr, "pivot:", pivot)
        return i + 1

def quickSort(arr, low = 0, high = -1):
        #whole array by default
        if high == -1:
                high = len(arr) -1

        if (low < high):
                partitionIndex = partition(arr, low, high)
                #recursively sort either side of the partition
                quickSort(arr, low, partitionIndex - 1)
                quickSort(arr, partitionIndex + 1, high)
        return arr

def main(n):
    print("Quick Sort:\n")
    arr = ordArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

    arr = shufArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

    arr = revArr(n)
    print(arr)
    print(quickSort(arr))
    print("--")

#https://www.geeksforgeeks.org/dsa/quick-sort-algorithm/
#Credit where it is due

if __name__ == '__main__':
        main(10)
